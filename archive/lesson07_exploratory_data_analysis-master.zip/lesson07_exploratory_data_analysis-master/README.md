# lesson07_exploratory_data_analysis

For more information on this topic, check out the following resources:

- [List of Resources from Data School](http://www.dataschool.io/best-python-pandas-resources/)
- [Another EDA Tutorial](https://www.datacamp.com/community/tutorials/exploratory-data-analysis-python#gs.T3TSKbk)
- [A discussion forum on the topic](https://www.kaggle.com/general/12796)
