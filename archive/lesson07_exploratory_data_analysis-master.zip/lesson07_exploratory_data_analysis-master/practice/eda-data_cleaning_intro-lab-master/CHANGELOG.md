### v0.11| 05.18.17

_Editor: Claire Oliver_

- Copy edits

### v0.1 | 04.28.17

_Editor: Sam Stack_

- Added CHANGELOG.md 

- Added '.DS_Store' & '*.ipynb_checkpoints' to .gitignore.

- text edits, wording edits and minor code adjustments.


### v0.0

_Author: Dave Yerrington_
