### v1.1 | 04.21.17

_Editor: Sam Stack_

- Added to .gitignore "DS.Store" & "*ipynb_checkpoints"
- Updated solution functions to take less similar arguments(argument structure similar to SNS plots). 
- Added information about "np.array" to bonus seaborn activity


### v1.0 | 02.27.17

_Editor: Kiefer Katovich_

- Formatted notebook for DSI v2

---

### v0.0

_Author: Kiefer Katovich and Dave Yerrington_
