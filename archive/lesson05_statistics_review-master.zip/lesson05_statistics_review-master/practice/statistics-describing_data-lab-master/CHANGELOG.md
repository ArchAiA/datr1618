### v0.1 | 04.21.17

_Editor: Sam Stack_

- added changelog
- Added to .gitignore "DS.Store" & "*ipynb_checkpoints"
- Added additional notes to qualitative solutions and converted cells to md.
- changed solution code to make it easier for readers to follow.

---

### v0.0

_Author: Matt Brems_
