Images should be stored in this folder, as needed.

Please try to store images locally whenever possible, to avoid broken links. 

Images may need to be optimized before uploading, to reduce file size. We recommend image optim or kraken.io.


The relative link to this folder from the lesson/lab would be:

`[name](./assets/images/file.png)`