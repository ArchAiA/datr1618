### v0.1 | 05.05.17

_Editor: Sam Stack_

- Added CHANGELOG.md 

- Added '.DS_Store' & '*.ipynb_checkpoints' to .gitignore.

- Fixed example code issues.


### v0.0

_Author: Joseph Nelson, Sam Stack_
